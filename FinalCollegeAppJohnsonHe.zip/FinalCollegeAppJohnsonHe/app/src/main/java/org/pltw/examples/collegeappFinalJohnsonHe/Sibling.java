package org.pltw.examples.collegeappFinalJohnsonHe;


public class Sibling extends FamilyMember{

    public Sibling (){
        super();
        super.setEmail("jhe87@claytonschools.net");
    }
    public Sibling (String firstName, String lastName){
        this.setFirstName(firstName);
        this.setLastName(lastName);
        super.setEmail("jhe87@claytonschools.net");
    }

    public String toString(){
        String output = "Sibling: " + this.getFirstName() + " " + this.getLastName();
        return output;
    }


}
